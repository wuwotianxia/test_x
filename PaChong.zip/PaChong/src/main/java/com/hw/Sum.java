package com.hw;

public class Sum {

    /**
     * 标题
     */
    private String title;

    /**
     * 日期
     */
    private String date;

    /**
     * 阅读数
     */
    private String num;

    /**
     * 封面图
     */
    private String fig;

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getNum() {
        return num;
    }

    public void setNum(String num) {
        this.num = num;
    }

    public String getFig() {
        return fig;
    }

    public void setFig(String fig) {
        this.fig = fig;
    }

    @Override
    public String toString() {
        return "Sum{" +
                "title='" + title + '\'' +
                ", date='" + date + '\'' +
                ", num='" + num + '\'' +
                ", fig='" + fig + '\'' +
                '}';
    }
}