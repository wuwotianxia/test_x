package com.hw;

import com.alibaba.fastjson.JSON;
import org.apache.poi.hssf.usermodel.*;
import org.apache.poi.ss.usermodel.HorizontalAlignment;
import org.apache.poi.ss.usermodel.VerticalAlignment;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class SumTest {
    public static void main(String[] args) throws FileNotFoundException, IOException {
        List<Sum> list = getInfo("https://www.aquanliang.com/blog", 10);
        for (Sum sum : list) {
            System.out.println(sum.toString());
        }
        testHSSFWorkbook(list);
    }

    //可以指定网址，并且按照需求爬取前多少页的数据
    public static List<Sum> getInfo(String url, int page) {
        List<Sum> sumList = new ArrayList<Sum>();
        for (int i = 1; i < page + 1; i++) {
            try {
                System.out.println("url:" + url);
                Document doc = Jsoup.connect(url).get();
                Elements table = doc.select("._1ySUUwWwmubujD8B44ZDzy");
                Elements spanList = table.select("span");
                /*//每次移除的时候,列表长度就会发生新的变化,所以要结合实际进行移除
                spanList.remove(0);*/

                //
                for (Element span : spanList) {

                    //标题
                    Elements divList = span.select("div");//div
                    Elements cList = divList.select("._3_JaaUmGUCjKZIdiLhqtfr");//查询.claa
                    Sum sum = new Sum();
                    if (cList != null && cList.size() > 0) {
                        sum.setTitle(cList.get(0).html().toString());
                    } else {
                        sum.setTitle(divList.get(0).html().toString());
                    }

                    //日期
                    Elements divList2 = span.select("._3TzAhzBA-XQQruZs-bwWjE");//div
                    StringBuffer stringBuffer = new StringBuffer();
                    stringBuffer.append(divList2.toString());
                    Pattern p = Pattern.compile("[0-9]{4}[-][0-9]{1,2}[-][0-9]{1,2}");
                    Matcher m = p.matcher(stringBuffer);
                    if (m.find()){
                        sum.setDate(m.group(0));
                    }else {
                        System.out.println("查询不到时间");
                    }

                    //阅读数
                    sumList.add(sum);
                    Elements divList3 = span.select("._2gvAnxa4Xc7IT14d5w8MI1");//div
                    StringBuffer stringBuffer2 = new StringBuffer();
                    stringBuffer2.append(divList3.toString());
                    stringBuffer2.delete(0,stringBuffer2.length()-20);
                    Pattern p2 = Pattern.compile("[0-9]+");
                    Matcher m2 = p2.matcher(stringBuffer2);
                    if (m2.find()){
                        sum.setNum(m2.group(0));
                    }else {
                        System.out.println("查询不到阅读量");
                    }

                    //封面图
                    Elements divList4 = span.select("._2ahG-zumH-g0nsl6xhsF0s");//div
                    Elements imgList = divList4.select("img");//查询.claa
                    StringBuffer stringBuffer4 = new StringBuffer();
                    stringBuffer4.append(imgList.toString());
                    String s = stringBuffer4.substring(10,104);
                    if (imgList != null && imgList.size() > 0) {
                        sum.setFig(s);
                    } else {
                        System.out.println("图片链接不存在");
                    }
                }

            } catch (IOException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }

            url = "https://www.aquanliang.com/blog/page/" + (i + 1);
        }
        return sumList;

    }

    public static void testHSSFWorkbook(List<Sum> list) throws IOException {
        HSSFWorkbook workbook = new HSSFWorkbook();//创建excel文件(workbook)

        HSSFSheet sheet = workbook.createSheet("圈量SCRM");
        HSSFRow row = sheet.createRow(0);//创建行 从0开始

        HSSFCellStyle style = workbook.createCellStyle();//设置单元格样式
        style.setAlignment(HorizontalAlignment.CENTER);//水平居中
        style.setVerticalAlignment(VerticalAlignment.CENTER);//垂直居中
        sheet.setDefaultColumnWidth(30);
        row.setHeightInPoints(25);
        Map<String, String> map = (Map<String, String>) getMap(list.get(0));
        //设置表头
        int c = 0;
        for (String key : map.keySet()) {
            HSSFCell cell = row.createCell(c);//创建行的单元格，从0开始
            cell.setCellValue(map.get(key));//设置单元格内容
            cell.setCellStyle(style);
            c++;
        }
        Map<Integer, Sum> sumMap = new HashMap<>();
        //除去表头
        for (int i = 1; i < list.size(); i++) {
            sumMap.put(i, list.get(i));
        }
        for (int i = 1; i <= sumMap.size(); i++) {
            HSSFRow rowInfo = sheet.createRow(i);
            rowInfo.setHeightInPoints(30);
            Map<String, String> map1 = (Map<String, String>) getMap(list.get(i));
            int j = 0;
            for (String key : map1.keySet()) {
                HSSFCell cellInfo = rowInfo.createCell(j);
                cellInfo.setCellValue(map1.get(key));
                cellInfo.setCellStyle(style);
                j++;
            }
        }
        FileOutputStream out = new FileOutputStream("D:\\sum.xlsx");
        workbook.write(out);
        out.close();

    }

    /**
     * json转map
     *
     * @param object
     * @return
     */
    public static Map<?, ?> getMap(Object object) {
        if (object == null) {
            throw new RuntimeException("对象为空,转json失败");
        }
        Map<String, Object> map = new HashMap<>();
        try {
            map = (Map) JSON.parse(JSON.toJSONString(object));
        } catch (Exception e) {
            System.out.println("对象转map转换失败");
        }
        return map;
    }


}